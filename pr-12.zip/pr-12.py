
def create_bank_account(initial_balance):
    balance = initial_balance

    def deposit(amount):
        nonlocal balance

        if amount <= 0:
            return "Amount must be greater than zero!"

        balance += amount
        return f"Deposit successful! Current balance: ₹{balance}"

    def withdraw(amount):
        nonlocal balance

        if amount <= 0:
            return "Amount must be greater than zero!"

        if amount > balance:
            return "Insufficient balance!"

        balance -= amount
        return f"Withdrawal successful! Current balance: ₹{balance}"

    def get_balance():
        return balance

    return {
        "deposit": deposit,
        "withdraw": withdraw,
        "get_balance": get_balance
    }


account = create_bank_account(1000)

while True:
    print("\n===== BANK MENU =====")
    print("1. Deposit Money")
    print("2. Withdraw Money")
    print("3. Check Balance")
    print("4. Exit")

    choice = input("Enter your choice (1-4): ")

    if choice == "1":
        amount = float(input("Enter deposit amount: ₹"))
        print(account["deposit"](amount))

    elif choice == "2":
        amount = float(input("Enter withdrawal amount: ₹"))
        print(account["withdraw"](amount))

    elif choice == "3":
        print(f"Current balance: ₹{account['get_balance']()}")

    elif choice == "4":
        print("Thank you for using our bank!")
        break

    else:
        print("Invalid choice! Please enter 1, 2, 3, or 4.")
